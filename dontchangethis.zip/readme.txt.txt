Ok, so you've come this far... you deserve it.

Here's the username and password...

username: gringo
password: oncemore